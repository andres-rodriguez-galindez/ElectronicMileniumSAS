CREATE DATABASE IF NOT EXISTS `bdunad05`;

USE `bdunad05`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `tabla05`;

CREATE TABLE `tabla05` (
  `codProd` int(15) NOT NULL,
  `nomProd` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `marcProd` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `precProd` decimal(10,2) NOT NULL,
  `cantProd` int(5) NOT NULL,
  PRIMARY KEY (`codProd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `tabla05` VALUES (1,"camaras","generica","40000.00",40),
(2,"telefonos ip","bars","300000.00",4),
(3,"celulares","lenovo","800000.00",9);


SET foreign_key_checks = 1;
